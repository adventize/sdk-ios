//
//  AppDelegate.h
//  AdvertiserSrc
//
//  Created by Valery Tikhonov on 3/13/13.
//  Copyright (c) 2013 Valery Tikhonov. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Advertiser.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@property (strong, nonatomic) UIWindow *window;

@end
