//
//  AdventizeTestViewController.m
//  AdventizeTest
//
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "AdventizeTestViewController.h"

@interface AdventizeTestViewController ()

@end

@implementation AdventizeTestViewController


- (IBAction)showCustomDesignedOffers:(id)sender
{
    [AdventizeSDK askForFetch:self];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (void)offerWallDownloaded:(BOOL)result
{
    if(result)
        [AdventizeSDK showOfferWallWindow:self.navigationController];
}

- (void)dealloc
{
    [super dealloc];
}

@end
