//
//  AdventizeTestViewController.m
//  AdventizeTest
//
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "AdventizeTestViewController.h"

@class PublisherManager;
@class AdvViewController;

@implementation AdventizeTestViewController


- (IBAction)showCustomDesignedOffers:(id)sender
{
    AdvViewController *offers = [[AdvViewController alloc] init];
    [self.navigationController pushViewController:offers animated:YES];
    [offers release];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (void)dealloc
{
    [super dealloc];
}

@end
