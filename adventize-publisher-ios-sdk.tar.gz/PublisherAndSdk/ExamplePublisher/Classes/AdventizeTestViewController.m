//
//  AdventizeTestViewController.m
//  AdventizeTest
//
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "AdventizeTestViewController.h"

@implementation AdventizeTestViewController

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (void)dealloc
{
    [super dealloc];
}

@end
