//
//  AdventizeTestViewController.h
//  AdventizeTest
//
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AdventizeSDK.h"
#import "AdventizeCallback.h"

@interface AdventizeTestViewController : UIViewController<AdventizeCallback>
{
}

- (IBAction)showCustomDesignedOffers:(id)sender;

@end

