//
//  AdventizeTestViewController.h
//  AdventizeTest
//
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AdventizeTestViewController : UIViewController
{
}

- (IBAction)showCustomDesignedOffers:(id)sender;

@end

