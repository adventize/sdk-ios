//
//  AdventizeTestAppDelegate.m
//  AdventizeTest
//
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "AdventizeTestAppDelegate.h"


@implementation AdventizeTestAppDelegate

@synthesize window;
@synthesize navController;

#pragma mark -
#pragma mark Application lifecycle

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{    
    
    // Override point for customization after application launch.

    [self.window addSubview:navController.view];
    [self.window makeKeyAndVisible];
    
    // Start Adventize session using application Id you got from adventize.com
    [Publisher startSession:@"6763"];
    //  Set your user ID before asking for fetch
    [Publisher setUserID:@"Vasya"];
    // Ask for fetch async
    [OfferWallAPI askForFetch:self];

    @autoreleasepool
    {
        NSMutableArray *locations = [NSMutableArray array];
        [locations addObject:@"MainMenu.ABC"];
        [Publisher askBanners:self andLocations:locations];
    }

    return YES;
}


- (void)applicationWillResignActive:(UIApplication *)application {

}


- (void)applicationDidEnterBackground:(UIApplication *)application {

}


- (void)applicationWillEnterForeground:(UIApplication *)application {

}


- (void)applicationDidBecomeActive:(UIApplication *)application {

}


- (void)applicationWillTerminate:(UIApplication *)application {

    [Publisher stopSession];
}


#pragma mark -
#pragma mark Memory management

- (void)applicationDidReceiveMemoryWarning:(UIApplication *)application {

}

- (void)onBannersLoaded:(NSArray *)banners
{
    @autoreleasepool
    {
        if([banners count])
        {
            Banner *banner = [banners objectAtIndex:0];
            if([banner checkStimul])
            {
                [[UIApplication sharedApplication] openURL:[banner url]];
            }
            else
            {
                CGRect webFrame = CGRectMake(10.0, 10.0, 320.0, 460.0);
                [banner setFrame:webFrame];
                [self.window addSubview:banner];
            }
        }
        else
            NSLog(@"Empty banner.");
    }
}

- (void)offerWallFinished:(NSArray *)offerWall
{
    NSLog(@"Got fetch callback");
    if(!offerWall || ![offerWall count])
    {
        NSLog(@"Empty offerwall!");
        return;
    }
//show offerwall, send impressions of shown items and make click on the first item (if exists)
    @autoreleasepool
    {
        NSMutableArray *impressions = [NSMutableArray array];
//show all items of offerwall, remember impressions
        OfferWallItem *item;
        for (NSUInteger i = 0; i < [offerWall count]; i++)
        {
            item = [offerWall objectAtIndex:i];
            NSLog(@"Name %@\n Desc %@\n Cost %@\n Payout %@\n Icon %@\n Click %@\n\n\n",
                    [item name], [item description], [item cost], [item payout], [item iconURL], [item clickURL]);
            [impressions addObject:[item campaignId]];
        }

//send impressions
        [OfferWallAPI sendImpressions:impressions andCallback:self];

//make click on the first item, if exists
        if ([offerWall count])
        {
            OfferWallItem *clickMe = [offerWall objectAtIndex:0];
            [OfferWallAPI sendClick:[clickMe clickURL]];
        }

//clear offerwall not to show same again
        [Publisher invalidateOffer];
    }
}

- (void)onSendImpressionsResult:(NSNumber *)ok
{
    NSLog(@"Got impressions callback.");
    if([ok boolValue])
        NSLog(@"Impressions were send.");
}

- (void)dealloc
{
    [navController release];
    [window release];
    [super dealloc];
}


@end
