//
// Created by Valery Tikhonov on 6/17/13.
//
// To change the template use AppCode | Preferences | File Templates.
//


#import <Foundation/Foundation.h>

#import "OnCloseListener.h"
#import "Publisher.h"

@class BannerEntity;
@class BannerClient;

@interface Banner : UIWebView<OnCloseListener>
{
    BannerClient *mClient;
    NSString *location;
    NSString *url;
    BOOL isStimul;
}

- (id)initWithEntity:(BannerEntity *)entity;

- (BOOL)checkStimul;

- (NSURL *)url;

@end