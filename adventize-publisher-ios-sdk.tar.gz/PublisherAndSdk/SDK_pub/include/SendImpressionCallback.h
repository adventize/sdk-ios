//
// Created by tihon on 4/15/13.
//
// To change the template use AppCode | Preferences | File Templates.
//


#import <Foundation/Foundation.h>

@protocol SendImpressionCallback <NSObject>
-(void) onSendImpressionsResult:(NSNumber *) ok;
@end