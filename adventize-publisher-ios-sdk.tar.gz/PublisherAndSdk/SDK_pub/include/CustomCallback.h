//
// Created by Valery Tikhonov on 7/5/13.
//
// To change the template use AppCode | Preferences | File Templates.
//


#import <Foundation/Foundation.h>


@interface CustomCallback : NSObject
{
    SEL mCallback;
    id mDelegate;
}

- (id)initWithCallback:(SEL) method andDelegate:(id)delegate;

- (void) callMethod:(NSDictionary *)params;
@end