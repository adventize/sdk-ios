//
//  PublisherSDK.h
//  PublisherSDK
//
//  Created by Valery Tikhonov on 3/14/13.
//  Copyright (c) 2013 Valery Tikhonov. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PublisherSDK : NSObject

@end
