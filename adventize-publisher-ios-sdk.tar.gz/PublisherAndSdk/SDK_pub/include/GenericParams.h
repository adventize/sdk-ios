//
//  GenericParams.h
//  prod-AdvertizerSrc
//
//  Created by Valery Tikhonov on 1/22/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CommonCrypto/CommonDigest.h>
#import <AdSupport/AdSupport.h>
#import <sys/utsname.h>

#import "NetClass.h"
#import "OpenUDID.h"
#import "Reachability.h"
#import "Responce.h"
#import "GAI.h"

#import <sys/sysctl.h>
#import <net/if_dl.h>
#import <sys/socket.h>
#import <net/if.h>
#import "Logger.h"

@interface GenericParams : NSObject
#define PARAM_PROTOCOL_NAME                 @"adventize_sdk"
#define PARAM_PROTOCOL_VERSION              @"2.1"

#define PARAM_SDK                           @"sdk_type"
#define PARAM_SDK_TYPE                      @"IOS"

#define PARAM_APP_ID                        @"app_id"
#define PARAM_DEVICE_ID                     @"idfa"
#define PARAM_OPEN_UDID                     @"open_udid"
#define PARAM_MAC_ADDR                      @"mac_addr"

#define PARAM_API_VERSION                   @"api_version"
#define PARAM_OS_VERSION                    @"os_version"
#define PARAM_DEVICE_TYPE                   @"device_type"

#define PARAM_LOCALE                        @"locale"
#define PARAM_TIMESTAMP                     @"timestamp"
#define PARAM_INTERNET                      @"internet"

#define PARAM_USER_ID                       @"uid"

#ifdef Develop
    #define HOST                                @"http://app.adventize.com/"
    #define PARAM_GAI_ID    @"UA-38797980-1"
#elif Master
    #define HOST                                @"http://workers.adventize.com/"
    #define PARAM_GAI_ID    @"UA-38797980-2"
#else
    #define HOST                                @"http://workers.adventize.com/"
    #define PARAM_GAI_ID    @"UA-38797980-1"
#endif

+ (NSMutableDictionary *) genericParameters;

+ (void)setSecret:(NSString*) secret;
+ (void)setAppId:(NSString*)appId;
+ (void)setUserID:(NSString *) id;

+ (void)setEnableLog:(BOOL)value;
+ (BOOL)isLogEnabled;

+ (NSString *)join:(NSArray *)array andSeperator:(char)separator;

+ (NSString*)getsAppId;

+ (NSString*)urlEncodeUTF8:(NSDictionary*) paramDict;
+ (NSDictionary *)urlDecodeUTF8:(NSString *) params;

+ (NSString*)getHashSecret:(NSString*)url;
+ (void)startSession;
+ (void)stopSession;
+ (void)sendGAAction:(NSString*)name;
@end
