//
//  Publisher.h
//
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "AskBannerCallback.h"
#import "CustomCallback.h"

@interface Publisher : NSObject
{
}

+ (void)enableLog:(BOOL)value;

+ (void)startSession:(NSString *)appId;

+ (void)setUserID:(NSString *)uid;

+ (void)addCallback:(NSString *)name andCallb:(CustomCallback*)callback;

+ (void)setUserRate:(long)balance;

+ (void)askBanners:(id<AskBannerCallback>)callback andLocations:(NSArray *)locations;

+ (void)invalidateBanners;

+ (void)invalidateBanners:(NSArray *)banners;

+ (void)invalidateOffer;

+ (void)setUpdateTime:(long)mills;

+ (void)stopSession;

@end
