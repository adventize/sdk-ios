//
//  Publisher.h
//
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#include <CommonCrypto/CommonDigest.h>

@interface Publisher : NSObject
{
}

+ (void)startSession:(NSString *)appId;

+ (void)invalidateOffer;

+ (void)setUserID:(NSString *)uid;

+ (void)setUserInGameBalance:(long)balance;

+ (void)stopSession;

@end
