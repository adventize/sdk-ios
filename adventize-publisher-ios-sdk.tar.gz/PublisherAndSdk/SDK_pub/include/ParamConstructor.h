//
// Created by tihon on 4/11/13.
//
// To change the template use AppCode | Preferences | File Templates.
//


#import <Foundation/Foundation.h>
#import "SBJSON.h"

#import "BannerEntity.h"
#import "OfferWallItem.h"
#import "GenericParams.h"
#import "Logger.h"

#define PARAM_RESOLUTION    @"resolution"
#define PARAM_USER_RATE     @"user_rate"
#define PARAM_AD_FORMAT     @"format"
#define OFFERS_LIMIT        @"15"

@interface ParamConstructor : NSObject

+ (void)setUserProperty:(long)value;

+ (NSString *)getUserProperty;

+ (NSMutableDictionary *)parseBannerList:(NSString *)jString;

+ (NSString *)getBannerUrl:(NSArray *)locations andFormat:(NSString *)format;

+ (NSMutableArray*)parseOfferWall:(NSString *)jString;

+ (NSString*)getFetchUrl:(NSString*)format;

+ (NSString *)getBasicUrl;

+ (NSString*)encodeImpressions:(NSMutableArray *)ids;

+ (NSString *)getScreenResolution;



@end