//
// Created by Valery Tikhonov on 4/22/13.
// Copyright (c) 2013 Valery Tikhonov. All rights reserved.
//
// To change the template use AppCode | Preferences | File Templates.
//


#import <Foundation/Foundation.h>
#import "AdventizeCallback.h"

@class UINavigationController;

@interface AdventizeSDK : NSObject

+(void)showOfferWallWindow:(UINavigationController *)controller;

+(void)askForFetch:(id<AdventizeCallback>)callback;

@end