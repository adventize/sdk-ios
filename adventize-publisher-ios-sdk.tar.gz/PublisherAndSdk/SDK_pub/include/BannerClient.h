//
// Created by Valery Tikhonov on 6/17/13.
//
// To change the template use AppCode | Preferences | File Templates.
//


#import <Foundation/Foundation.h>

#import "OnCloseListener.h"

@interface BannerClient : NSObject<UIWebViewDelegate>

@property(nonatomic) id <OnCloseListener> mCallback;

- (id)initWithCallback:(id<OnCloseListener>)callback;

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request
 navigationType:(UIWebViewNavigationType)navigationType;


@end