//
// Created by Valery Tikhonov on 4/25/13.
//
// To change the template use AppCode | Preferences | File Templates.
//


#import <Foundation/Foundation.h>

@protocol AskBannerCallback <NSObject>
- (void) onBannersLoaded:(NSArray*)banners;
@end