//
//  BannerEntity.h
//  PublisherLight
//
//  Created by Valery Tikhonov on 4/25/13.
//
//

#import <Foundation/Foundation.h>

@interface BannerEntity : NSObject
{
    NSString *locationName;
    NSString *url;
    NSString *body;
}

- (id)initWithDictionary:(NSDictionary *)itemDict;

- (NSString *)getLocationName;

- (NSString *)getUrl;

- (NSString *)getBody;

@end
