//
// Created by tihon on 4/15/13.
//
// To change the template use AppCode | Preferences | File Templates.
//


#import <Foundation/Foundation.h>

#import "SendImpressionCallback.h"
#import "AskFetchCallback.h"
#import "AskBannerCallback.h"

@interface OfferWallAPI : NSObject

+ (void)askForFetch:(id<AskFetchCallback>)callback;

+ (void)sendImpressions:(NSMutableArray *)impressions andCallback:(id <SendImpressionCallback>)callback;

+ (void)sendClick:(NSString *)url;

+ (void)setCallback:(id<SendImpressionCallback>)callback;

@end