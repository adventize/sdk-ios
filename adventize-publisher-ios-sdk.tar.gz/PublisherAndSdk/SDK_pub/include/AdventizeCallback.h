//
// Created by Valery Tikhonov on 4/23/13.
// Copyright (c) 2013 Valery Tikhonov. All rights reserved.
//
// To change the template use AppCode | Preferences | File Templates.
//


#import <Foundation/Foundation.h>

@protocol AdventizeCallback <NSObject>
-(void)offerWallDownloaded:(BOOL)result;
@end