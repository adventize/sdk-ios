//
//  BannerModel.h
//  PublisherLight
//
//  Created by Valery Tikhonov on 4/25/13.
//
//

#import <Foundation/Foundation.h>

#import "AskBannerCallback.h"
#import "BannerEntity.h"
#import "Banner.h"
#import "GenericParams.h"
#import "ParamConstructor.h"
#import "Responce.h"
#import "NetClass.h"
#import "CustomCallback.h"

@interface BannerModel : NSObject
{
    NSMutableDictionary *mBanners;
    NSMutableDictionary *mInvalidateTimestamp;
    NSMutableDictionary *mCustomCallbacks;
    long mUpdateTime;
    BOOL mBannerTask;
    id <AskBannerCallback> mCallback;
}

+ (BannerModel *)getInstance;

- (void)setMCallback:(id<AskBannerCallback>)callback;

- (void)addCallback:(NSString *)name andCallb:(CustomCallback*)callback;

- (void)processCallback:(NSString *)name andParams:(NSString *)params;

- (void)setUpdateTime:(long)updateTime;

- (void)invalidate:(NSArray *)locations;

- (void)invalidateAll;

- (void)askBanners:(NSArray *)locations;

@end
