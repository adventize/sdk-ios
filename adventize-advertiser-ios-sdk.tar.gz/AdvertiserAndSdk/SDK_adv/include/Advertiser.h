//
//  Advertiser.h
//
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface Advertiser : NSObject

+ (void)startSession:(NSString *)appId secret:(NSString *)secret;

+ (void)sendAction:(NSString *)action;

+ (void)stopSession;

@end
