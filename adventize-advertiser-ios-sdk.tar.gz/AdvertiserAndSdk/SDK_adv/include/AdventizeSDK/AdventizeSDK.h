//
//  AdventizeSDK.h
//  AdventizeSDK
//
//  Created by Valery Tikhonov on 3/13/13.
//  Copyright (c) 2013 Valery Tikhonov. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AdventizeSDK : NSObject

@end
