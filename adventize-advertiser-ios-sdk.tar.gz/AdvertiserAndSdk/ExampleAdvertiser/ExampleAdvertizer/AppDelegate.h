//
//  AppDelegate.h
//  ExampleAdvertizer
//
//  Created by Valery Tikhonov on 2/26/13.
//  Copyright (c) 2013 Valery Tikhonov. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;

@end
