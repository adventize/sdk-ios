//
//  ViewController.m
//  AdvertizerSrc
//
//  Created by Valery Tikhonov on 2/26/13.
//  Copyright (c) 2013 Valery Tikhonov. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)quit:(id)sender
{
	exit(0);
}

@end
