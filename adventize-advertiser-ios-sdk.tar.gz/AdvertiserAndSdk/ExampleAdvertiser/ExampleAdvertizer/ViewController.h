//
//  ViewController.h
//  AdvertizerSrc
//
//  Created by Valery Tikhonov on 2/26/13.
//  Copyright (c) 2013 Valery Tikhonov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

- (IBAction)quit:(id)sender;

@end
