//
//  main.m
//  ExampleAdvertizer
//
//  Created by Valery Tikhonov on 2/26/13.
//  Copyright (c) 2013 Valery Tikhonov. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
