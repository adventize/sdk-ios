//
//  OfferWallItem.h
//
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface OfferWallItem : NSObject
{
    NSDictionary *_itemDict;
}

- (id)initWithDictionary:(NSDictionary *)itemDict;

- (NSString *)name;
- (NSString *)description;
- (NSString *)cost;
- (NSString *)payout;
- (NSString *)iconURL;
- (NSString *)clickURL;
- (NSString *)id;

- (NSString *)appId;
- (NSString *)campaignId;

- (NSString *)timeToReward;

- (BOOL)expired;

- (BOOL)simpleItem;

- (BOOL)onetimeItem;

- (NSDictionary *)itemDict;

- (NSArray *)extendedItems;

@end
