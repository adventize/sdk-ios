//
// Created by Valery Tikhonov on 11/25/13.
//


#import <Foundation/Foundation.h>

@class JsonObjectRequest;


@interface AdventizeRequest : NSObject

- (id)initWithRequest:(JsonObjectRequest *)request;


- (void)cancel;
@end