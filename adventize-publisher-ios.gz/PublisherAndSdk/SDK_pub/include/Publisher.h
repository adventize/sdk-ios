//
//  Publisher.h
//
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>

#import "SendImpressionCallback.h"
#import "AdventizeRequest.h"
#import "Advertiser.h"

@interface Publisher : Advertiser

- (void)setUserRate:(long)balance;

- (AdventizeRequest *)requestBanners:(void (^)(NSDictionary *))callback andLocations:(NSArray *)locations;

- (AdventizeRequest *)requestOffers:(void (^)(NSArray *))callback;

- (void)sendImpressions:(NSArray *)impressions andCallback:(id <SendImpressionCallback>)callback;
@end
