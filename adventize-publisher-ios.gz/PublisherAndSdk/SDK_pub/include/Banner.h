//
// Created by Valery Tikhonov on 6/17/13.
//
// To change the template use AppCode | Preferences | File Templates.
//


#import <Foundation/Foundation.h>

#import "OnCloseListener.h"
#import "Publisher.h"
#import "BannerEntity.h"

@class BannerClient;

@interface Banner : UIWebView<OnCloseListener>


- (id)initWithEntity:(BannerEntity *)entity;

- (void)addCustomCallback:(void (^)(NSArray *))customCallback andKey:(NSString *)key;

- (void)addErrorCallback:(void (^)())errorCallback;

- (BOOL)checkStimul;

- (NSURL *)url;

@end