//
// Created by Valery Tikhonov on 6/17/13.
//
// To change the template use AppCode | Preferences | File Templates.
//


#import <Foundation/Foundation.h>

@protocol OnCloseListener <NSObject>

-(void)onCloseBanner;

@end