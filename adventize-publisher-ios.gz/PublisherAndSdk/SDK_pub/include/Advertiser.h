//
//  Advertiser.h
//
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@class URL;

@interface Advertiser : NSObject
{
    NSString *mAppId;
}

@property (nonatomic, readwrite) NSOperationQueue * (^getRequestQueue)();

+ (void)enableLog:(BOOL)value;

- (id)initWithAppId:(NSString *)appId secret:(NSString *)secret;

- (void)setUserID:(NSString *)uid;

- (void)startSession;

- (void)sendAction:(NSString *)action;

- (NSOperationQueue *)rq;

- (URL *)genericParameters;

- (void)stopSession;

@end
