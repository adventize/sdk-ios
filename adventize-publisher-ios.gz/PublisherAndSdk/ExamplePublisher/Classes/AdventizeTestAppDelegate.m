//
//  AdventizeTestAppDelegate.m
//  AdventizeTest
//
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//
#import "AdventizeTestAppDelegate.h"
#import "NetLib.h"

Publisher *sAdventize;

@implementation AdventizeTestAppDelegate

@synthesize window;
@synthesize navController;

#define publisher [AdventizeTestAppDelegate getAdventize]

#pragma mark -
#pragma mark Application lifecycle

+ (Publisher *)getAdventize
{
    if (!sAdventize)
    {
        NSString *yourAppId = @"9787";
        NSString *yourSecret = @"bdfWhgCURNuKvPD02OZ0qA";
        sAdventize = [[Publisher alloc] initWithAppId:yourAppId secret:yourSecret];
        sAdventize.getRequestQueue = [^NSOperationQueue *()
        {
            return [[NetLib newRequestQueue] autorelease];
        } copy];
    }
    return sAdventize;
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{

    [self.window addSubview:navController.view];
    [self.window makeKeyAndVisible];

    // Start Adventize session using application Id you got from adventize.com
    [Publisher enableLog:YES];
    [publisher startSession];
    [publisher setUserID:@"Vasya"];
    [publisher requestOffers:^(NSArray *offerwall)
    {
        [self performSelectorOnMainThread:@selector(offerWallFinished:) withObject:offerwall waitUntilDone:NO];
    }];


    NSMutableArray *locations = [NSMutableArray array];
    [locations addObject:@"offerwall"];
    [publisher requestBanners:^(NSDictionary *banners)
    {
        //remember, that returned callback will be called in other thread, than main
        [self performSelectorOnMainThread:@selector(onBannersLoaded:) withObject:banners waitUntilDone:NO];
    }
                 andLocations:
                         locations];

    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application
{
}


- (void)applicationDidEnterBackground:(UIApplication *)application
{
}


- (void)applicationWillEnterForeground:(UIApplication *)application
{
}


- (void)applicationDidBecomeActive:(UIApplication *)application
{
}


- (void)applicationWillTerminate:(UIApplication *)application
{
    [publisher stopSession];
}


#pragma mark -
#pragma mark Memory management

- (void)applicationDidReceiveMemoryWarning:(UIApplication *)application
{
}

/* Callbacks, called in blocks as an example. */

//This callback is called if itunes can't be open
- (void)errorCallback
{
    NSLog(@"Can't open iTunes!");
}

//This example callback is called, when user in banner makes some specified action
- (void)exampleCallback:(NSArray *)params
{
    NSLog(@"exampleCallback");
    if (params)
        NSLog(@"params %@", params);
    else
        NSLog(@"no params");
}

- (void)onBannersLoaded:(NSDictionary *)banners
{
    if(!banners)
    {
        NSLog(@"Empty banner list!");
        return;
    }

    @autoreleasepool
    {
        if ([banners count])
        {
            BannerEntity *bannerEntity = [banners objectForKey:@"offerwall"];
            if (bannerEntity) //if banner entity found
            {//create banner object
                Banner *banner = [[[Banner alloc] initWithEntity:bannerEntity] autorelease];
                if ([banner checkStimul])   //check banner stimulation
                {//if it is stimulated - open in browser
                    [[UIApplication sharedApplication] openURL:[banner url]];
                }
                else
                {//if it is not stimulated - use it as normal webview

                    //you can add error callback to banner. It will be called if iTunes can't be open.
                    [banner addErrorCallback:^()
                    {
                        [self errorCallback];
                    }];

                    //you can add your custom callback for banner client (see more at dashboard)
                    [banner addCustomCallback:^(NSArray *array)
                    {
                        [self exampleCallback:array];
                    } andKey:@"shop"];

                    CGRect webFrame = CGRectMake(10.0, 10.0, 320.0, 460.0);
                    [banner setFrame:webFrame];
                    [self.window addSubview:banner];
                }
            }
        }
        else
            NSLog(@"Empty banners.");
    }
}

- (void)offerWallFinished:(NSArray *)offerWall
{
    if (!offerWall || ![offerWall count])
    {
        NSLog(@"Empty offerwall!");
        return;
    }
//show offerwall, send impressions of shown items and make click on the first item (if exists)
    @autoreleasepool
    {
        NSMutableArray *impressions = [NSMutableArray array];
//show all items of offerwall, remember impressions
        OfferWallItem *item;
        for (NSUInteger i = 0; i < [offerWall count]; i++)
        {
            item = [offerWall objectAtIndex:i];
            NSLog(@"Name %@\n Desc %@\n Cost %@\n Payout %@\n Icon %@\n Click %@\n\n\n",
                    [item name], [item description], [item cost], [item payout], [item iconURL], [item clickURL]);
            if ([item campaignId])   //if campId exists
                [impressions addObject:[item campaignId]];
        }

//send impressions
        [publisher sendImpressions:impressions andCallback:self];

//make click on the first item, if exists
        if ([offerWall count])
        {
            OfferWallItem *clickMe = [offerWall objectAtIndex:0];
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[clickMe clickURL]]];
        }
    }
}

- (void)onSendImpressionsResult:(BOOL)ok
{
    NSLog(@"Got impressions callback.");
    if (ok) //If impressions is OK - never mind
        NSLog(@"Impressions were send.");
    //if they are not OK - try to save and send them later
}

- (void)dealloc
{
    [navController release];
    [window release];
    [super dealloc];
}


@end
