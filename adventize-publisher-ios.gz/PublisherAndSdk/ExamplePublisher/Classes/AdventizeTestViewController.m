//
//  AdventizeTestViewController.m
//  AdventizeTest
//
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "AdventizeTestViewController.h"


@implementation AdventizeTestViewController

- (void)dealloc
{
    [super dealloc];
}

@end
